/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.opower.connectionpool;

import java.sql.*;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Properties;
import java.util.Vector;

/**
 *
 * @author Jiachen Duan
 */
public class OpowerConnectionDriver implements Driver {

    public static final String URL_PREFIX = "jdbc:postgresql:";
    private static final int MAJOR_VERSION = 1;
    private static final int MINOR_VERSION = 0;
    private OpowerConnectionPool pool;

    public OpowerConnectionDriver(String driver, String url,
            String user, String password)
            throws ClassNotFoundException,
            InstantiationException, IllegalAccessException,
            SQLException {


        DriverManager.registerDriver(this);
        Class.forName(driver).newInstance();
        pool = new OpowerConnectionPool(url, user, password);
    }

    @Override
    public Connection connect(String url, Properties prprts) throws SQLException {
        if (!acceptsURL(url)) {
            return null;
        }

        return pool.getConnection();
    }

    @Override
    public boolean acceptsURL(String string) throws SQLException {
        return string.startsWith(URL_PREFIX);
    }

    @Override
    public DriverPropertyInfo[] getPropertyInfo(String string, Properties prprts) throws SQLException {
        return new DriverPropertyInfo[0];
    }

    @Override
    public int getMajorVersion() {
        return MAJOR_VERSION;
    }

    @Override
    public int getMinorVersion() {
        return MINOR_VERSION;
    }

    @Override
    public boolean jdbcCompliant() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.opower.connectionpool;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Jiachen Duan
 */
public class Tester {

    public String theuser, password, creditcard, emailaddress;
    public double balance;

    static {
        try {
            new com.opower.connectionpool.OpowerConnectionDriver("org.postgresql.Driver",
                    "jdbc:postgresql://localhost:5432/postgres?", "postgres", "root");
        } catch (Exception e) {
        }
    }

    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:postgresql:jdcpool");
    }

    /**
     * Try to get the connection 5 times and see how many connection are created
     * through the Server status monitor;
     */
    //Pass: There is only one connection created on the server; 
    //Fail: There are more than one connection on the server
    @Test
    public static void test_case1() {
        try {
            Tester t = new Tester();

            for (int i = 0; i < 4; i++) {
                OpowerConnection conn = (OpowerConnection) t.getConnection();
                PreparedStatement stmnt;
                String sql = "select book_id, book_name, publish_year from book";
                stmnt = conn.prepareStatement(sql);
                ResultSet rs = stmnt.executeQuery();
                while (rs.next()) {
                    System.out.println(rs.getString("book_id"));
                    System.out.println(rs.getString("book_name"));
                }
                OpowerConnectionPool pool = conn.getPool();

                conn.releaseConnection(conn);

                //  System.out.println("pool size: " + pool.getPoolSize());
                int pooSize = pool.getPoolSize();
                assertEquals(1, pooSize, 0);
                stmnt.close();

            }
        } catch (Throwable e) {
            e.printStackTrace();
        }

    }

    /**
     * Try to get the connection 1,000 times and see how many connection are
     * created through the Server status monitor
     */
    //Pass: There is only one connection created on the server 
    //Fail: There are more than one connection on the server
    public static void test_case2() {
        try {
            Tester t = new Tester();

            for (int i = 0; i < 1000; i++) {
                OpowerConnection conn = (OpowerConnection) t.getConnection();
                PreparedStatement stmnt;
                String sql = "select book_id, book_name, publish_year from book";
                stmnt = conn.prepareStatement(sql);
                ResultSet rs = stmnt.executeQuery();
                while (rs.next()) {
                    System.out.println(rs.getString("book_id"));
                    System.out.println(rs.getString("book_name"));
                }
                OpowerConnectionPool pool = conn.getPool();

                conn.releaseConnection(conn);

                //  System.out.println("pool size: " + pool.getPoolSize());
                int pooSize = pool.getPoolSize();
                assertEquals(1, pooSize, 0);
                stmnt.close();

            }
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    /**
     * djc: To test the releaseConnection() method, Set the pool maximun size
     * into 3 and try to getConnection() 4 times.For fill up the pool, first
     * three times we don't call releaseConnection At the fourth time, we call
     * the releaseConnection method.
     */
    //Pass: pool size is 3 after the 4th time get Connection 
    //Fail: pool size is 4 after the 4th time get Connection 
    public static void test_case3() {
        try {
            Tester t = new Tester();

            for (int i = 0; i < 4; i++) {
                OpowerConnection conn = (OpowerConnection) t.getConnection();
                PreparedStatement stmnt;
                String sql = "select book_id, book_name, publish_year from book";
                stmnt = conn.prepareStatement(sql);
                ResultSet rs = stmnt.executeQuery();
                while (rs.next()) {
                    System.out.println(rs.getString("book_id"));
                    System.out.println(rs.getString("book_name"));
                }
                OpowerConnectionPool pool = conn.getPool();

                if (i > 2) {

                    conn.releaseConnection(conn);
                    int pooSize = pool.getPoolSize();
                    assertEquals(3, pooSize, 0);
                }
                // System.out.println("pool size 1: " + pool.getPoolSize());

                stmnt.close();

            }
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    static class ThreadTest extends Thread {

        @Override
        public void run() {
            Tester t = new Tester();
            OpowerConnection conn;
            try {
                System.out.println("Start run ThreadTest System time: " + System.currentTimeMillis());
                conn = (OpowerConnection) t.getConnection();
                PreparedStatement stmnt;
                String sql = "select book_id, book_name, publish_year from book";
                stmnt = conn.prepareStatement(sql);
                ResultSet rs = stmnt.executeQuery();
                while (rs.next()) {
                    System.out.println(rs.getString("book_id"));
                    System.out.println(rs.getString("book_name"));
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

        }
    }

    static class ThreadTest_insert extends Thread {

        @Override
        public void run() {
            Tester t = new Tester();
            OpowerConnection conn;
            try {
                System.out.println("Start run ThreadTest_insert System time: " + System.currentTimeMillis());
                conn = (OpowerConnection) t.getConnection();
                PreparedStatement stmnt;
                String sql = " INSERT INTO book(book_name) VALUES (?) ";
                for (int i = 0; i < 1000000000; i++) {
                    stmnt = conn.prepareStatement(sql);
                    
                    stmnt.setString(1, "James " + i);
                    
                    int rs = stmnt.executeUpdate();
                    conn.releaseConnection(conn);
                }



            } catch (SQLException ex) {
                ex.printStackTrace();
            }

        }
    }
    /*
     * Test the whether the connection pool is really thread safe
     */
    //Pass: connection start syste.currentTime of the two thread are different
    //Fail: connection start syste.currentTime of the two thread are same
    public static void test_case4() {
        try {
            ThreadTest_insert t = new ThreadTest_insert();
            ThreadTest s = new ThreadTest();
            t.start();
            s.start();
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) throws SQLException {

        // test_case1();
        // test_case2();
        //test_case3();
        test_case4();
    }
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.opower.connectionpool;

import java.util.ArrayList;

/**
 * To Check and realse those locked connections
 *
 * @author Jiachen Duan
 */
public class OpowerConnectionReleaser extends Thread {

    private OpowerConnectionPool pool;
    //djc:!!!For testing purpose to set Run the cleaDeadconnection every 3 second,
    //In the rea program, I will set it into like 30 mins
    private final long delay = 1800000;

    public OpowerConnectionReleaser(OpowerConnectionPool pool) {
        this.pool = pool;
    }

    @Override
    public void run() {


        while (true) {
            try {
                sleep(delay);

            } catch (InterruptedException ex) {
            }

            pool.cleanDeadConncections();
        }
    }
}

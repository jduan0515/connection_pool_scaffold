/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.opower.connectionpool;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Jiachen Duan
 */
public class OpowerConnectionPool implements ConnectionPool {

    private ArrayList<OpowerConnection> connections;
    private String url;
    private String user;
    private String password;
    final private long timeout = 120000;
    private OpowerConnectionReleaser releaser;
    private final int poolsize = 3;

    public OpowerConnectionPool(String url, String user, String password) {
        this.connections = new ArrayList(poolsize);
        this.url = url;
        this.user = user;
        this.password = password;
        releaser = new OpowerConnectionReleaser(this);
        //djc: When the connection pool is instantiated, the connectionReleaser will be 
        //triggered, 
        releaser.start();
    }

    public synchronized void cleanDeadConncections() {
        long servingtime = System.currentTimeMillis() - timeout;
        if (connections != null) {
            for (OpowerConnection c : connections) {
                OpowerConnection conn = c;
                //djc: when the connection is still being used and also has been used longer than the 
                //timeout time limit and functionally doesn't do it's job, then the code will 
                // get rid of this connection from the connection pool
                if ((conn.isServing() && (servingtime > conn.getServiceStartTime()) && (!conn.checkConnStaus()))) {
                    //djc:remove the current connection from the connection pool
                    connections.remove(c);
                }
            }
        }
    }

    public synchronized int getPoolSize() {
        return connections.size();
    }

    @Override
    public synchronized Connection getConnection() throws SQLException {
        OpowerConnection c;
        //djc: Iterate all the connection inside this connection pool
        for (OpowerConnection oc : connections) {
            c = oc;
            //djc: check whether the connection is being used right now
            if (c.serve()) {
                return c;
            }
        }

        Connection conn = DriverManager.getConnection(url, user, password);
        //djc: Create a new Opower connection
        c = new OpowerConnection(this, conn);
        //djc: set the connection serve status into serving
        c.serve();
        //djc: add this new OpowerConnection into 
        //**No matter how many connections in the pool right now,
        //we just add it to the pool first, later on we will decide to keep it or 
        //delete it when we process the returnconnections.

        connections.add(c);

        return c;
    }

    @Override
    public synchronized void releaseConnection(Connection connection) throws SQLException {
        if (connection instanceof OpowerConnection) {
            OpowerConnection c = (OpowerConnection) connection;
            //djc: **IF the size of the connections is less than or equal maximum pool size
            //then return the current connection to pool Or just remove it from pool and close the connection**
            if (connections.size() < poolsize) {
                c.returnConnection();
            } else {
                removeConnection(c);
            }

        }
    }

    public synchronized void removeConnection(OpowerConnection conn) throws SQLException {
        connections.remove(conn);
        conn.close();
    }
}

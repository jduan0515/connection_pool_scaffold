/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.opower.connectionpool;

import java.sql.*;
import java.util.Map;
import java.util.Properties;

/**
 *
 * @author Jiachen Duan
 */
public class OpowerConnection implements Connection {

    private OpowerConnectionPool pool;
    private Connection conn;
    //djc: Whether the connection is serving
    private boolean serving;
    //djc: serving start time
    private long serviceStartTime;

    public OpowerConnection(OpowerConnectionPool pool, Connection conn) {
        this.pool = pool;
        this.conn = conn;
        this.serving = false;
        this.serviceStartTime = 0;
    }

    public boolean isServing() {
        return serving;
    }

    public long getServiceStartTime() {
        return serviceStartTime;
    }

    /**
     * djc: Check whether the connection can be used
     *
     * @return
     */
    public boolean checkConnStaus() {
        try {
            conn.getMetaData();
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    /**
     * djc:Check whether the current connection is serving right now, if it is
     * serving, return false, or change the serveFlag into true, and set the
     * start service time.
     *
     * @return
     */
    public synchronized boolean serve() {
        if (serving) {
            return false;
        } else {
            serving = true;
            serviceStartTime = System.currentTimeMillis();
            return true;
        }
    }

    /**
     * djc:return the connection into the connectionPool
     */
    public void releaseConnection(Connection conn) throws SQLException {
        pool.releaseConnection(this);
    }

    public void returnConnection() {
        serving = false;
    }

    public OpowerConnectionPool getPool() {
        return this.pool;
    }
    //<editor-fold defaultstate="collapsed" desc="djc:Override methods ">

    @Override
    public void close() throws SQLException {
        conn.close();
    }

    @Override
    public Statement createStatement() throws SQLException {
        return conn.createStatement();
    }

    @Override
    public PreparedStatement prepareStatement(String string) throws SQLException {
        return conn.prepareCall(string);
    }

    @Override
    public CallableStatement prepareCall(String string) throws SQLException {
        return conn.prepareCall(string);
    }

    @Override
    public String nativeSQL(String string) throws SQLException {
        return conn.nativeSQL(string);
    }

    @Override
    public void setAutoCommit(boolean bln) throws SQLException {
        conn.setAutoCommit(bln);
    }

    @Override
    public boolean getAutoCommit() throws SQLException {
        return conn.getAutoCommit();
    }

    @Override
    public void commit() throws SQLException {
        conn.commit();
    }

    @Override
    public void rollback() throws SQLException {
        conn.rollback();
    }

    @Override
    public boolean isClosed() throws SQLException {
        return conn.isClosed();
    }

    @Override
    public DatabaseMetaData getMetaData() throws SQLException {
        return conn.getMetaData();
    }

    @Override
    public void setReadOnly(boolean bln) throws SQLException {
        conn.setReadOnly(bln);
    }

    @Override
    public boolean isReadOnly() throws SQLException {
        return conn.isReadOnly();
    }

    @Override
    public void setCatalog(String string) throws SQLException {
        conn.setCatalog(string);
    }

    @Override
    public String getCatalog() throws SQLException {
        return conn.getCatalog();
    }

    @Override
    public void setTransactionIsolation(int i) throws SQLException {
        conn.setTransactionIsolation(i);
    }

    @Override
    public int getTransactionIsolation() throws SQLException {
        return conn.getTransactionIsolation();
    }

    @Override
    public SQLWarning getWarnings() throws SQLException {
        return conn.getWarnings();
    }

    @Override
    public void clearWarnings() throws SQLException {
        conn.clearWarnings();
    }

    @Override
    public Statement createStatement(int i, int i1) throws SQLException {
        return conn.createStatement();
    }

    @Override
    public PreparedStatement prepareStatement(String string, int i, int i1) throws SQLException {
        return conn.prepareStatement(string, i, i1);
    }

    @Override
    public CallableStatement prepareCall(String string, int i, int i1) throws SQLException {
        return conn.prepareCall(string, i, i1);
    }

    @Override
    public Map<String, Class<?>> getTypeMap() throws SQLException {
        return conn.getTypeMap();
    }

    @Override
    public void setTypeMap(Map<String, Class<?>> map) throws SQLException {
        conn.setTypeMap(map);
    }

    @Override
    public void setHoldability(int i) throws SQLException {
        conn.setHoldability(i);
    }

    @Override
    public int getHoldability() throws SQLException {
        return conn.getHoldability();
    }

    @Override
    public Savepoint setSavepoint() throws SQLException {
        return conn.setSavepoint();
    }

    @Override
    public Savepoint setSavepoint(String string) throws SQLException {
        return conn.setSavepoint(string);
    }

    @Override
    public void rollback(Savepoint svpnt) throws SQLException {
        conn.rollback(svpnt);
    }

    @Override
    public void releaseSavepoint(Savepoint svpnt) throws SQLException {
        conn.releaseSavepoint(svpnt);
    }

    @Override
    public Statement createStatement(int i, int i1, int i2) throws SQLException {
        return conn.createStatement(i, i1, i2);
    }

    @Override
    public PreparedStatement prepareStatement(String string, int i, int i1, int i2) throws SQLException {
        return conn.prepareCall(string, i, i1, i2);
    }

    @Override
    public CallableStatement prepareCall(String string, int i, int i1, int i2) throws SQLException {
        return conn.prepareCall(string, i, i1, i2);
    }

    @Override
    public PreparedStatement prepareStatement(String string, int i) throws SQLException {
        return conn.prepareStatement(string, i);
    }

    @Override
    public PreparedStatement prepareStatement(String string, int[] ints) throws SQLException {
        return conn.prepareStatement(string, ints);
    }

    @Override
    public PreparedStatement prepareStatement(String string, String[] strings) throws SQLException {
        return conn.prepareStatement(string, strings);
    }

    @Override
    public Clob createClob() throws SQLException {
        return conn.createClob();
    }

    @Override
    public Blob createBlob() throws SQLException {
        return conn.createBlob();
    }

    @Override
    public NClob createNClob() throws SQLException {
        return conn.createNClob();
    }

    @Override
    public SQLXML createSQLXML() throws SQLException {
        return conn.createSQLXML();
    }

    @Override
    public boolean isValid(int i) throws SQLException {
        return conn.isValid(i);
    }

    @Override
    public void setClientInfo(String string, String string1) throws SQLClientInfoException {
        conn.setClientInfo(string, string1);
    }

    @Override
    public void setClientInfo(Properties prprts) throws SQLClientInfoException {
        conn.setClientInfo(prprts);
    }

    @Override
    public String getClientInfo(String string) throws SQLException {
        return conn.getClientInfo(string);
    }

    @Override
    public Properties getClientInfo() throws SQLException {
        return conn.getClientInfo();
    }

    @Override
    public Array createArrayOf(String string, Object[] os) throws SQLException {
        return conn.createArrayOf(string, os);
    }

    @Override
    public Struct createStruct(String string, Object[] os) throws SQLException {
        return conn.createStruct(string, os);
    }

    @Override
    public <T> T unwrap(Class<T> type) throws SQLException {
        return conn.unwrap(type);
    }

    @Override
    public boolean isWrapperFor(Class<?> type) throws SQLException {
        return conn.isWrapperFor(type);
    }
    //</editor-fold>
}
